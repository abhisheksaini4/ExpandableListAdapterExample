package example.abhiandroid.ExpandableListAdapterExample;

public class ChildItemsInfo {

    private String songName = "";

    public String getName() {
        return songName;
    }

    public void setName(String songName) {
        this.songName = songName;
    }

}